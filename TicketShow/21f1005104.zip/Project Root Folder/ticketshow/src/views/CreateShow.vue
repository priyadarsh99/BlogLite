<script setup>
import CreateShow from '../components/CreateShow.vue'
</script>

<template>
  <main>
    <CreateShow />
  </main>
</template>
