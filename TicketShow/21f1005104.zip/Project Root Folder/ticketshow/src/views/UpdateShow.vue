<script setup>
import UpdateShow from '../components/UpdateShow.vue'
</script>

<template>
  <main>
    <UpdateShow />
  </main>
</template>
