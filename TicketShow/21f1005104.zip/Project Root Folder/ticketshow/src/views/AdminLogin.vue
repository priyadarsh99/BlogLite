<script setup>
import AdminLogin from '../components/AdminLogin.vue'
</script>

<template>
  <main>
    <AdminLogin />
  </main>
</template>
