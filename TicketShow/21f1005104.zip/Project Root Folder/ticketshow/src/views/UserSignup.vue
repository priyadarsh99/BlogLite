<script setup>
import UserSignup from '../components/UserSignup.vue'
</script>

<template>
  <main>
    <UserSignup />
  </main>
</template>
