<script setup>
import MyProfile from '../components/MyProfile.vue'
</script>

<template>
  <main>
    <MyProfile/>
  </main>
</template>
