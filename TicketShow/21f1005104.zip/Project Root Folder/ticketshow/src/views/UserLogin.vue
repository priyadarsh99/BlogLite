<script setup>
import UserLogin from '../components/UserLogin.vue'
</script>

<template>
  <main>
    <UserLogin />
  </main>
</template>
