<script setup>
import AdminDashboard from '../components/AdminDashboard.vue'
</script>

<template>
  <main>
    <AdminDashboard/>
  </main>
</template>
