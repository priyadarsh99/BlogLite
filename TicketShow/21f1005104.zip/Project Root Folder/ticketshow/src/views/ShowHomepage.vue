<script setup>
import ShowHomepage from '../components/ShowHomepage.vue'
</script>

<template>
  <main>
    <ShowHomepage />
  </main>
</template>
