<script setup>
import RateShow from '../components/RateShow.vue'
</script>

<template>
  <main>
    <RateShow/>
  </main>
</template>
