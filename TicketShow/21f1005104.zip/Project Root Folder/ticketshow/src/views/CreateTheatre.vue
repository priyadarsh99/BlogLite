<script setup>
import CreateTheatre from '../components/CreateTheatre.vue'
</script>

<template>
  <main>
    <CreateTheatre />
  </main>
</template>
