<script setup>
import UserDashboard from '../components/UserDashboard.vue'
</script>

<template>
  <main>
    <UserDashboard/>
  </main>
</template>
