<script setup>
import BookShow from '../components/BookShow.vue'
</script>

<template>
  <main>
    <BookShow/>
  </main>
</template>
