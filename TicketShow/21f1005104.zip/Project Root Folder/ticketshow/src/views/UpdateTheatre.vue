<script setup>
import UpdateTheatre from '../components/UpdateTheatre.vue'
</script>

<template>
  <main>
    <UpdateTheatre />
  </main>
</template>
